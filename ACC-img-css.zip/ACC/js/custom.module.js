/*
 * load custom view
 */
var app = angular.module('viewCustom', ['angularLoad']);
